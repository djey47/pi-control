#invalid_argument_error.rb - exception to be risen when provided argument is not as expected

class InvalidArgumentError < StandardError

end