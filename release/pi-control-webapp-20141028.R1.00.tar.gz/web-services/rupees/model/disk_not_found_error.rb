# disk_not_found_error.rb - exception to be risen when no disk was found with specified id

class DiskNotFoundError < StandardError

end