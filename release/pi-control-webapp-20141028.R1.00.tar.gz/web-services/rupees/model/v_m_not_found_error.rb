# v_m_not_found_error.rb - exception to be risen when no vm was found with specified id

class VMNotFoundError < StandardError

end